Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/shortcodes-ultimate

Thank you for your contribution.
