<?php
/*
Plugin Name: Amigos Aliados Wordpress Plugin
Description: Agrega información desde un archivo CSV y lo muestra por medio de shortcodes
Author: Mario Minondo
*/

