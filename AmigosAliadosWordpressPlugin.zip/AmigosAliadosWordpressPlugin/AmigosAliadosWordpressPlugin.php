<?php
/*
Plugin Name: Amigos Aliados Wordpress Plugin
Description: Agrega información desde un archivo CSV y lo muestra por medio de shortcodes
Author: Mario Minondo
*/

require_once plugin_dir_path(__FILE__) . 'includes/aawp-functions.php';
